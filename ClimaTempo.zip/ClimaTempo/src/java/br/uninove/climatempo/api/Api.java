package br.uninove.climatempo.api;


public class Api {
    
}
